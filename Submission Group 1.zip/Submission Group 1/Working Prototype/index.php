<?php
include("header.php");
?>
<p>The Music Tracker is a way for users to store information about their favorite artists and songs, as well as the performaces they've seen. Users can add comments on artists' performances, and can view the profiles of other users who have similar tastes. The Music Tracker incorporates the use of a database in order to store all of the users' information in one place. 
<br><br>
By: 
<br>

Emily Evans<br>
Miguel Fernandez<br>
Brenton Smelser<br>
Shannon Smith<br>


</p>
